import { system, world } from '@minecraft/server'

system.afterEvents.scriptEventReceive.subscribe(data => {

    if (data.id == 'achievements:achievement') {

        const achievementData = data.message.split('/')

        world.sendMessage(`${data.sourceEntity.nameTag} has reached the achievement: §a[${achievementData[0]}]`)
        data.sourceEntity.runCommandAsync(`playsound random.levelup @s`)
        data.sourceEntity.runCommandAsync(`xp ${achievementData[1]}L @s`)

    } else if (data.id == 'achievements:achievementHidden') {

        const achievementData = data.message.split('/')

        world.sendMessage(`${data.sourceEntity.nameTag} has reached the achievement: §5[${achievementData[0]}]`)
        data.sourceEntity.runCommandAsync(`playsound random.levelup @s`)
        data.sourceEntity.runCommandAsync(`xp ${achievementData[1]}L @s`)

    }
})